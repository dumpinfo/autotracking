//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by chaseTrack.rc
//
#define IDI_ICON1                       101
#define IDD_DIALOG_LOGDIR               102
#define IDD_DIALOG_EXIST                103
#define IDD_DIALOG_OPTION               104
#define IDD_DIALOG_BATCHCONFIRM         105
#define IDD_DIALOG_BATCHFINISH          106
#define IDC_EDIT_LOGDIR                 1000
#define IDC_RADIO_TRACKER1              1001
#define IDC_RADIO_TRACKER2              1002
#define IDC_RADIO_TRACKER3              1003
#define IDC_RADIO_TRACKER4              1004
#define IDC_TRACKER                     1006
#define IDC_EDIT_RBINS                  1008
#define IDC_EDIT_GBINS                  1009
#define IDC_EDIT_BBINS                  1010
#define IDC_DIALOG_BATCHLABEL           1010
#define IDC_RADIO_LOGV1                 1011
#define IDC_RADIO_LOGV2                 1012
#define IDC_RADIO1                      1014
#define IDC_RADIO_LOGV3                 1014
#define IDC_RADIO_TRACKER5              1014
#define IDC_RADIO_TRACKER6              1015
#define IDC_RADIO_TRACKER7              1016
#define IDC_RADIO2                      1017
#define IDC_RADIO_TRACKER8              1017
#define IDC_RADIO_LOGV4                 1017
#define IDC_RADIO_                      1017
#define IDC_RADIO_LOG                   1018
#define IDC_RADIO_LOGV5                 1018
#define IDC_RADIO3                      1019
#define IDC_RADIO_TRACKER9              1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
